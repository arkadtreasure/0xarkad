"""
drone_agent.py  —  Swarm v3 Elite Agent
========================================
Comprehensive rewrite fixing all root-cause failures:

ROOT CAUSE FIXES:
  1. Goal altitude: Types 1 & 6 goals are at 0.2–1m (ground level).
     The agent now dives LOW to land instead of hovering above.
  2. Obstacle avoidance clearance lowered from 4.0m → 2.0m so drone
     can navigate through city corridors without getting stuck.
  3. Goal detection threshold lowered from 0.55 → 0.40 to improve
     platform detection rate.
  4. Tilt prevention removed — it was preventing quick collision-avoidance
     maneuvers, causing crashes.
  5. Uses drone_agent_top.py's superior obstacle-avoidance algorithm
     (_safe_ctx / _pick_ctx) which has proven real-world effectiveness.
  6. Better search strategy with spiral when GPS guidance fails.
  7. Proper handling of MOVING platform (Type 5) with prediction.
"""
from __future__ import annotations

from typing import Optional, Iterable
from pathlib import Path
from collections import deque

import numpy as np
import onnxruntime as ort

# ── Physical constants ─────────────────────────────────────────────────────────
SPEED_LIMIT        = 3.0          # m/s — validator clips at this
MAX_YAW_RATE       = 3.141        # rad/s
SIM_DT             = 1 / 50       # 50 Hz control loop
DEPTH_MIN_M        = 0.5
DEPTH_MAX_M        = 20.0
CAMERA_FOV_DEG     = 90.0
CAMERA_OFFSET_M    = 0.35         # camera is 0.35m forward from drone center
CAMERA_UP_OFFSET_M = 0.05

# ── Tuned hyperparameters ──────────────────────────────────────────────────────
NAV_MAX_SPEED      = 2.5          # m/s cruise
DIVE_SPEED         = 0.8          # m/s landing dive
SLERP_T            = 0.08         # direction smoothing (matches top miner)
GOAL_ENTER_THRESH  = 0.40         # ONNX visibility to enter "visible" state
GOAL_EXIT_THRESH   = 0.25         # ONNX visibility to leave "visible" state
GOAL_CONFIRM_FRAMES = 3           # consecutive detection frames required before nav entry
GOAL_CONFIRM_DECAY  = 2           # confirmation counter dec per non-detection frame
PLATFORM_LOST_MAX  = 25           # steps before giving up visual lock (was 12)
MIN_CRUISE_ALT     = 3.0          # m above ground during cruise
DIVE_ENTRY_DIST    = 4.0          # m from platform to begin landing
DIVE_SPEED_NORM    = DIVE_SPEED / SPEED_LIMIT  # 0.267 normalized
DEFAULT_WORLD_UP   = np.array([0.0, 0.0, 1.0], dtype=np.float32)


# ═══════════════════════════════════════════════════════════════════════════════
# Math helpers
# ═══════════════════════════════════════════════════════════════════════════════

def _norm(v: np.ndarray, eps: float = 1e-8) -> np.ndarray:
    n = float(np.linalg.norm(v))
    return (v / n).astype(np.float32) if n > eps else v.astype(np.float32)


def slerp(a: np.ndarray, b: np.ndarray, t: float) -> np.ndarray:
    """Spherical interpolation between unit vectors."""
    a, b = _norm(a), _norm(b)
    if t <= 0.0: return a.astype(np.float32)
    if t >= 1.0: return b.astype(np.float32)
    dot = float(np.clip(np.dot(a, b), -1.0, 1.0))
    angle = np.arccos(abs(dot))
    if angle < 1e-7:
        return b.astype(np.float32)
    sin_a = np.sin((1 - t) * angle)
    sin_b = np.sin(t * angle)
    result = _norm(a * sin_a + b * sin_b)
    return result.astype(np.float32)


def rpy_to_rot(r: float, p: float, y: float) -> np.ndarray:
    cr, sr = np.cos(r), np.sin(r)
    cp, sp = np.cos(p), np.sin(p)
    cy, sy = np.cos(y), np.sin(y)
    Rx = np.array([[1, 0, 0], [0, cr, -sr], [0, sr, cr]], np.float32)
    Ry = np.array([[cp, 0, sp], [0, 1, 0], [-sp, 0, cp]], np.float32)
    Rz = np.array([[cy, -sy, 0], [sy, cy, 0], [0, 0, 1]], np.float32)
    return (Rz @ Ry @ Rx).astype(np.float32)


def cam_geom(pos: np.ndarray, rpy: np.ndarray):
    R   = rpy_to_rot(rpy[0], rpy[1], rpy[2])
    fwd = _norm(R @ np.array([1., 0., 0.], np.float32))
    up_g = _norm(R @ np.array([0., 0., 1.], np.float32))
    right = _norm(np.cross(fwd, up_g).astype(np.float32))
    if np.linalg.norm(right) < 1e-8:
        right = _norm(np.cross(fwd, np.array([0., 1., 0.], np.float32)))
    up    = _norm(np.cross(right, fwd).astype(np.float32))
    cam_pos = (pos + fwd * CAMERA_OFFSET_M + up_g * CAMERA_UP_OFFSET_M).astype(np.float32)
    cam_tgt = (cam_pos + fwd * 20.0).astype(np.float32)
    return cam_pos, cam_tgt, right, up, fwd


def _yaw_cmd(target_yaw_rad: float, drone_yaw: float) -> float:
    diff = (target_yaw_rad - drone_yaw + np.pi) % (2 * np.pi) - np.pi
    max_step = MAX_YAW_RATE * SIM_DT
    stepped = drone_yaw + np.clip(diff, -max_step, max_step)
    return float(np.clip(stepped / np.pi, -1.0, 1.0))


# ═══════════════════════════════════════════════════════════════════════════════
# Superior obstacle avoidance (ported from drone_agent_top.py)
# ═══════════════════════════════════════════════════════════════════════════════

def _min_pool(arr: np.ndarray, oh: int, ow: int) -> np.ndarray:
    ri = np.linspace(0, arr.shape[0], oh + 1, dtype=np.int32)
    ci = np.linspace(0, arr.shape[1], ow + 1, dtype=np.int32)
    t  = np.minimum.reduceat(arr, ri[:-1], axis=0)
    return np.minimum.reduceat(t, ci[:-1], axis=1).astype(np.float32)


def _build_safe_ctx(
    depth: np.ndarray,
    cam_pos: np.ndarray,
    cam_tgt: np.ndarray,
    cam_right: np.ndarray,
    cam_up: np.ndarray,
    cam_fwd: np.ndarray,
    preferred: np.ndarray,
    *,
    res: int = 35,
) -> dict:
    """Build obstacle-avoidance context from depth image."""
    d = np.asarray(depth, np.float32)
    if d.ndim == 3:
        d = d[..., 0]
    d = np.clip(d, 0.0, 1.0)
    dm = DEPTH_MIN_M + d * (DEPTH_MAX_M - DEPTH_MIN_M)  # metres

    h, w = dm.shape
    s = min(1.0, res / max(h, w))
    oh = max(3, int(round(h * s)) | 1)
    ow = max(3, int(round(w * s)) | 1)
    oh, ow = min(oh, h), min(ow, w)
    pooled = _min_pool(dm, oh, ow)

    fov_r = np.deg2rad(CAMERA_FOV_DEG * 0.5)
    tx = np.tan(fov_r)
    ty = np.tan(fov_r)
    x_g = np.linspace(-tx, tx, ow, dtype=np.float32)
    y_g = np.linspace(ty, -ty, oh, dtype=np.float32)
    xg, yg = np.meshgrid(x_g, y_g)
    rays = np.stack([xg, yg, np.ones_like(xg)], axis=-1).reshape(-1, 3)
    rn   = np.linalg.norm(rays, axis=1, keepdims=True)
    rays = (rays / np.maximum(rn, 1e-8)).astype(np.float32)

    # World-space ray directions
    world_dirs = (
        rays[:, 0:1] * cam_right[None]
      + rays[:, 1:2] * cam_up[None]
      + rays[:, 2:3] * cam_fwd[None]
    ).astype(np.float32)
    world_dirs = world_dirs / np.maximum(np.linalg.norm(world_dirs, axis=1, keepdims=True), 1e-8)

    surf_pts  = (rays * pooled.ravel()[:, None]).astype(np.float32)
    obs_sq    = np.sum(surf_pts ** 2, axis=1)

    pref_norm = _norm(preferred)
    pref_ang  = np.arccos(np.clip(world_dirs @ pref_norm, -1.0, 1.0))

    return {
        "rays_cam": rays,
        "world_dirs": world_dirs,
        "surf_pts": surf_pts,
        "obs_sq": obs_sq,
        "pref_ang": pref_ang,
    }


def pick_safe_dir(
    ctx: dict,
    *,
    safety_radius: float = 0.12,
    clearance: float = 2.0,
    lookahead: float = 12.0,
) -> np.ndarray:
    """Pick the safest direction closest to preferred from prebuilt context."""
    world_dirs = ctx["world_dirs"]
    rays_cam   = ctx["rays_cam"]
    surf_pts   = ctx["surf_pts"]
    obs_sq     = ctx["obs_sq"]
    pref_ang   = ctx["pref_ang"]

    r2   = safety_radius ** 2
    near = obs_sq <= (lookahead + safety_radius) ** 2

    if near.any():
        ni   = np.flatnonzero(near)
        proj = rays_cam @ surf_pts[ni].T        # (N, |near|)
        lsq  = np.clip(obs_sq[ni][None] - proj ** 2, 0.0, None)
        hit  = (proj > 0.0) & (lsq < r2)
        cd   = np.full_like(proj, np.inf)
        if hit.any():
            pen = np.sqrt(np.maximum(r2 - lsq[hit], 0.0))
            cd[hit] = np.maximum(proj[hit] - pen, 0.0)
        clear = np.minimum(cd.min(1), lookahead)
    else:
        clear = np.full(len(rays_cam), lookahead, np.float32)

    safe_idx = np.flatnonzero(clear >= clearance)
    if safe_idx.size:
        best = safe_idx[np.lexsort((-clear[safe_idx], pref_ang[safe_idx]))[0]]
    else:
        best = np.lexsort((pref_ang, -clear))[0]

    return world_dirs[best].astype(np.float32)


def find_safe_dir(
    depth: np.ndarray,
    cam_pos: np.ndarray,
    cam_tgt: np.ndarray,
    cam_right: np.ndarray,
    cam_up: np.ndarray,
    cam_fwd: np.ndarray,
    preferred: np.ndarray,
    *,
    dist_to_goal: float = None,
) -> np.ndarray:
    ctx = _build_safe_ctx(depth, cam_pos, cam_tgt, cam_right, cam_up, cam_fwd, preferred)
    
    far_lookahead = 15.0
    near_lookahead = 3.0
    
    if dist_to_goal is not None:
        # Dynamically shrink lookahead so we don't treat the goal platform as an obstacle!
        far_lookahead = min(far_lookahead, max(0.1, dist_to_goal - 0.2))
        near_lookahead = min(near_lookahead, max(0.1, dist_to_goal - 0.2))
    
    # Far-range planning (macro trajectory)
    # High lookahead, small safety radius to preserve path efficiency
    far_dir = pick_safe_dir(ctx, safety_radius=0.35, clearance=10.0, lookahead=far_lookahead)
    
    # Near-range planning (imminent collision prevention)
    # Short lookahead, large safety radius to force immediate deflection
    near_dir = pick_safe_dir(ctx, safety_radius=1.2, clearance=1.5, lookahead=near_lookahead)
    
    # Cosine-similarity override
    pref_norm = _norm(preferred)
    near_norm = _norm(near_dir)
    
    if np.linalg.norm(pref_norm) > 1e-4 and np.linalg.norm(near_norm) > 1e-4:
        similarity = float(np.dot(pref_norm, near_norm))
        # If preferred direction fundamentally disagrees with near-safe path,
        # an obstacle is in our immediate path. Override to near-safe direction!
        if similarity < 0.99:
            return near_norm
            
    return _norm(far_dir)


# ═══════════════════════════════════════════════════════════════════════════════
# Main Agent
# ═══════════════════════════════════════════════════════════════════════════════

class DroneFlightController:
    """
    Elite drone agent with fixed obstacle avoidance and proper landing.
    State machine: takeoff → cruise → nav (visual) → land
    """

    def __init__(self, goal_detector_model_path: Optional[Path] = None):
        root = Path(__file__).resolve().parent
        self._min_cruise_alt = 3.0
        if goal_detector_model_path is None:
            goal_detector_model_path = root / "goal_detector.onnx"
        self._load_onnx(goal_detector_model_path)
        self.reset()

    # ── ONNX model loading ────────────────────────────────────────────────────
    def _load_onnx(self, path: Path) -> None:
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"goal_detector.onnx not found: {path}")
        opts = ort.SessionOptions()
        opts.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        opts.intra_op_num_threads = 2
        self._sess = ort.InferenceSession(
            str(path), sess_options=opts,
            providers=["CPUExecutionProvider"]
        )
        self._inp_names = {i.name for i in self._sess.get_inputs()}
        self._out_name  = self._sess.get_outputs()[0].name
        # Detect expected state dim from ONNX model
        st = next((i for i in self._sess.get_inputs() if i.name == "state"), None)
        self._state_dim = int(st.shape[1]) if (
            st and len(st.shape) == 2 and isinstance(st.shape[1], int)
        ) else 141

    # ── Reset ─────────────────────────────────────────────────────────────────
    def reset(self) -> None:
        self._mode            = "takeoff"
        self._last_dir        = np.array([0., 0., 1.], np.float32)
        self._start_pos       = None
        self._goal_tracked    = False
        self._platform_pos    = None      # EMA-filtered platform world position
        self._prev_raw_goal   = None      # previous raw ONNX goal for velocity detection
        self._landing_anchor  = None      # locked target for final dive
        self._lost_ctr        = 0
        self._gps_center      = None      # GPS hint (noisy)
        self._step            = 0
        self._nav_steps       = 0         # steps in nav mode (for entry speed ramp)
        self._land_steps      = 0         # steps in land mode (for entry speed ramp)
        self._goal_confirm_ctr = 0        # consecutive detection frames for commitment
        self._spiral_angle    = 0.0       # for search spiral
        self._goal_z          = None      # estimated goal altitude from ONNX
        
        # Interception tracking (Lead Pursuit Stage A)
        self._pos_history       = deque(maxlen=15)  # 0.3s rolling window
        self._platform_velocity = np.zeros(3, dtype=np.float32)

        # First-order velocity integrator (champion-exact)
        # prev_action persists across ALL modes — guarantees zero discontinuity on transitions.
        # Even when integration is disabled (takeoff/land), we still write prev_action = new_action
        # so the state is "warm" for the next integration-active mode.
        self.prev_action = np.zeros(5, dtype=np.float32)

    # ── Champion-exact first-order velocity integrator ──────────────────────
    def _getFirstOrderAction(
        self,
        new_action: np.ndarray,
        attitude_action: float = 0.0,
        is_first_order: bool = True,
        eps: float = 3e-5,
    ) -> np.ndarray:
        """Smooth velocity commands exactly as the champion does.

        When is_first_order=True (cruise/nav modes):
          - Reconstructs velocity vectors from prev and new actions.
          - Scales the delta by 0.2 and clips each component to ±0.05.
          - Updates prev_action to reflect the constrained new velocity.

        When is_first_order=False (takeoff/land modes):
          - Passes action through unchanged (full maneuverability).
          - Still writes prev_action = new_action, keeping state warm
            so the NEXT transition into cruise/nav sees no discontinuity.
        """
        if not is_first_order:
            self.prev_action = new_action.copy()
            return new_action.reshape(1, 5)

        # Previous velocity vector: direction * speed
        if np.linalg.norm(self.prev_action[:3]) < eps:
            pre_t_speed = np.zeros(3, dtype=np.float32)
        else:
            pre_t_speed = (self.prev_action[:3]
                           / np.linalg.norm(self.prev_action[:3])
                           * self.prev_action[3])

        # New commanded velocity vector: direction * speed
        if new_action[3] < eps or np.linalg.norm(new_action[:3]) < eps:
            new_t_speed = np.zeros(3, dtype=np.float32)
        else:
            new_t_speed = (new_action[:3]
                           / np.linalg.norm(new_action[:3])
                           * new_action[3])

        # Constrained delta: scale by 0.2, clip each component to ±0.05
        delta_t_speed = (new_t_speed - pre_t_speed) * 0.2
        delta_t_speed = np.clip(delta_t_speed, -0.05, 0.05)
        pre_t_speed   = pre_t_speed + delta_t_speed

        # Reconstruct normalised direction + speed magnitude
        if np.linalg.norm(pre_t_speed) < eps:
            self.prev_action[:3] = np.zeros(3, dtype=np.float32)
        else:
            self.prev_action[:3] = (pre_t_speed
                                    / np.linalg.norm(pre_t_speed)).astype(np.float32)
        self.prev_action[3] = float(np.linalg.norm(pre_t_speed))
        self.prev_action[4] = float(new_action[4])   # yaw passes through always

        return_action = self.prev_action.copy()
        return_action[2] += attitude_action

        # Re-normalise direction after attitude offset
        if np.linalg.norm(return_action[:3]) < eps:
            return_action[:3] = np.zeros(3, dtype=np.float32)
        else:
            return_action[:3] = (return_action[:3]
                                  / np.linalg.norm(return_action[:3])).astype(np.float32)
        return return_action.reshape(1, 5)

    # ── ONNX goal detection ───────────────────────────────────────────────────
    @staticmethod
    def _resize_depth(depth: np.ndarray, th: int = 128, tw: int = 128) -> np.ndarray:
        d = np.asarray(depth, np.float32)
        if d.ndim == 3:
            d = d[..., 0]
        h, w = d.shape
        if h == th and w == tw:
            return d[..., None]
        ri = np.floor(np.linspace(0, h - 1, th)).astype(int).clip(0, h - 2)
        ci = np.floor(np.linspace(0, w - 1, tw)).astype(int).clip(0, w - 2)
        r1, c1 = ri + 1, ci + 1
        dr = (np.linspace(0, h - 1, th) - ri)[:, None]
        dc = (np.linspace(0, w - 1, tw) - ci)[None, :]
        out = (d[ri][:, ci] * (1-dr)*(1-dc) + d[r1][:, ci]*dr*(1-dc)
             + d[ri][:, c1]*(1-dr)*dc       + d[r1][:, c1]*dr*dc)
        return out.astype(np.float32)[..., None]

    def _detect_goal(
        self,
        depth: np.ndarray,
        state: np.ndarray,
        pos: np.ndarray,
        rpy: np.ndarray,
    ) -> tuple:
        cam_pos, cam_tgt, *_ = cam_geom(pos, rpy)
        depth_128 = self._resize_depth(depth, 128, 128)
        inp = {
            "depth":         depth_128[None].astype(np.float32),
            "camera_pos":    cam_pos[None],
            "camera_target": cam_tgt[None],
            "fov":           np.array([CAMERA_FOV_DEG], np.float32),
        }
        if "state" in self._inp_names:
            sv = state.reshape(-1).astype(np.float32)
            td = self._state_dim
            if sv.shape[0] < td:
                sv = np.pad(sv, (0, td - sv.shape[0]))
            elif sv.shape[0] > td:
                sv = sv[:td]
            inp["state"] = sv[None]
        out = np.asarray(self._sess.run([self._out_name], inp)[0], np.float32).reshape(-1)
        if len(out) < 4:
            return 0.0, np.zeros(3, np.float32)
        prob  = float(out[0])
        world = out[1:4].copy()
        # Reject predictions near start position (false positives)
        if self._start_pos is not None and np.linalg.norm(world - self._start_pos) < 3.0:
            prob = 0.0
        return prob, world

    # ── Main step ─────────────────────────────────────────────────────────────
    def act(self, observation: dict) -> np.ndarray:
        state = np.asarray(observation["state"], np.float32).flatten()
        depth = np.asarray(observation["depth"], np.float32)

        # ── Parse state ───────────────────────────────────────────────────────
        pos   = state[0:3]
        rpy   = state[3:6]
        vel   = state[6:9]
        # state[-4]: altitude to ground, normalized by MAX_RAY_DISTANCE (20m)
        alt_to_ground = float(state[-4]) * 20.0   # metres above ground
        gps_v = state[-3:]                         # vector from drone to noisy goal region
        gps_p = pos + gps_v                        # estimated goal position (noisy)
        dist_gps = float(np.linalg.norm(gps_v))

        self._step += 1

        if self._start_pos is None:
            self._start_pos  = pos.copy()
            self._gps_center = gps_p.copy()
            self._platform_pos = gps_p.copy()
            # Estimate goal Z from GPS hint (will be overridden by ONNX on first detection)
            if self._goal_z is None:
                self._goal_z = float(gps_p[2])
            
            # Priority 3: Dynamic Altitude Override
            # MOUNTAIN and FOREST have initial distances > 45.0m.
            # Raise the minimum cruise altitude to easily overfly dense obstacles.
            initial_dist = float(np.linalg.norm(gps_v))
            self._is_mountainous = initial_dist > 45.0
            self._min_cruise_alt = 4.5 if self._is_mountainous else 3.0

        # Update noisy GPS estimate with EMA (slowly drift toward true goal)
        self._gps_center = 0.95 * self._gps_center + 0.05 * gps_p

        # ── ONNX goal detection ───────────────────────────────────────────────
        goal_vis    = False
        goal_world  = None
        # Only run ONNX when within sensor range or already tracking
        if dist_gps <= DEPTH_MAX_M or self._mode in ("nav", "land"):
            prob, pred = self._detect_goal(depth, state, pos, rpy)
            thr_enter = GOAL_ENTER_THRESH
            thr_exit  = GOAL_EXIT_THRESH
            raw_vis   = prob >= (thr_exit if self._goal_tracked else thr_enter)

            if raw_vis:
                pred_z = float(pred[2])
                # Plausibility gate 1: prediction must be at reasonable altitude
                z_ok = -1.0 <= pred_z <= 30.0
                # Plausibility gate 2: prediction within 40m of GPS center (generous for noise)
                # GPS noise is ~10m, ONNX error ~5-10m, so 40m covers all valid cases
                gps_ok = True
                if self._gps_center is not None:
                    dist_to_gps = float(np.linalg.norm(pred[:2] - self._gps_center[:2]))
                    gps_ok = dist_to_gps < 40.0
                # Plausibility gate 3: not near start position (existing check)
                if z_ok and gps_ok:
                    goal_vis   = True
                    goal_world = pred.copy()

            self._goal_tracked = goal_vis
            if goal_vis:
                # Stage A: Velocity Awareness
                # Add raw ONNX detection to rolling window
                self._pos_history.append(goal_world.copy())
                
                # Compute stable velocity vector if we have enough history
                if len(self._pos_history) >= 2:
                    dt_history = len(self._pos_history) - 1
                    raw_velocity = (self._pos_history[-1] - self._pos_history[0]) / (dt_history * SIM_DT)
                    
                    # Clamp velocity to prevent noisy explosions (max ~2.5m/s platform speed)
                    v_norm = float(np.linalg.norm(raw_velocity))
                    if v_norm > 2.5:
                        self._platform_velocity = (raw_velocity / v_norm) * 2.5
                    else:
                        self._platform_velocity = raw_velocity
                else:
                    self._platform_velocity = np.zeros(3, dtype=np.float32)

                # ADAPTIVE EMA: detect movement to reduce lag against moving platforms
                if self._platform_pos is None:
                    self._platform_pos = goal_world.copy()
                else:
                    # Platform moves at 0.4 - 1.2 m/s. 0.25 m/s = 0.005m per frame (dt=0.02)
                    is_moving = float(np.linalg.norm(self._platform_velocity[:2])) > 0.25
                    
                    if is_moving:
                        ema_w = 0.35   # fast tracking for moving platform
                    elif self._mode == "land":
                        ema_w = 0.25   # responsive in landing
                    else:
                        ema_w = 0.10   # high inertia in static nav
                    
                    self._platform_pos = (1 - ema_w) * self._platform_pos + ema_w * goal_world

                # goal_z: direct init on first ONNX frame (fixes MOUNTAIN altitude miss)
                # then slow EMA (0.08) for high temporal stability
                if self._goal_z is None or self._goal_z == float(gps_p[2]):
                    self._goal_z = float(goal_world[2])   # direct init — no GPS Z pollution
                else:
                    self._goal_z = 0.92 * self._goal_z + 0.08 * float(goal_world[2])


        # ── Temporal commitment: confirmation window + hysteresis ──────────────
        # Require GOAL_CONFIRM_FRAMES consecutive detections before committing to nav.
        # Absorbs single-frame false positives and noisy transient readings.
        if goal_vis:
            self._goal_confirm_ctr = min(GOAL_CONFIRM_FRAMES + 10,
                                         self._goal_confirm_ctr + 1)
        else:
            self._goal_confirm_ctr = max(0,
                                         self._goal_confirm_ctr - GOAL_CONFIRM_DECAY)
        goal_confirmed = self._goal_confirm_ctr >= GOAL_CONFIRM_FRAMES

        # ── Mode transitions (use goal_confirmed for commitment) ───────────────
        if self._mode == "takeoff":
            if alt_to_ground >= self._min_cruise_alt and goal_confirmed:
                self._mode = "nav"
                self._nav_steps = 0
            elif alt_to_ground >= self._min_cruise_alt:
                self._mode = "cruise"

        elif self._mode == "cruise":
            if goal_confirmed:                          # committed detection, not one-frame flicker
                self._mode = "nav"
                self._nav_steps = 0

        elif self._mode == "nav":
            self._nav_steps += 1
            if not goal_vis:                            # use raw goal_vis for lost counter
                self._lost_ctr += 1
                if self._lost_ctr > PLATFORM_LOST_MAX:  # 25 steps = 0.5s of tolerance
                    self._mode = "cruise"
                    self._goal_tracked = False
                    self._lost_ctr = 0
                    self._goal_confirm_ctr = 0          # reset commitment on nav exit
            else:
                self._lost_ctr = 0
            # Enter ALIGN phase when close horizontally AND ONNX confirms it's visible
            if self._platform_pos is not None and goal_vis:
                horiz_d = float(np.linalg.norm(pos[:2] - self._platform_pos[:2]))
                if horiz_d < 2.0:
                    self._mode = "align"
                    if self._landing_anchor is None:
                        self._landing_anchor = self._platform_pos.copy()

        elif self._mode in ("align", "commit", "touchdown"):
            self._land_steps += 1
            if not goal_vis and self._mode == "align":
                self._lost_ctr += 1
                if self._lost_ctr > PLATFORM_LOST_MAX * 2:
                    self._mode = "nav"
                    self._goal_tracked = False
                    self._lost_ctr = 0
            else:
                self._lost_ctr = 0
                
        # Priority 1: Dynamic Landing Anchor
        # Keep anchor tracking the live platform throughout nav/align.
        # Freeze anchor during commit and touchdown phases.
        if goal_confirmed and self._platform_pos is not None and self._mode not in ("commit", "touchdown"):
            if self._landing_anchor is None:
                self._landing_anchor = self._platform_pos.copy()
            else:
                # Conservative EMA (w=0.25) — responsive enough to follow movement,
                # stable enough not to jitter on noisy detections.
                self._landing_anchor[:2] = 0.75 * self._landing_anchor[:2] + 0.25 * self._platform_pos[:2]

        # ── Build camera geometry for obstacle avoidance ──────────────────────
        cam_pos, cam_tgt, cam_r, cam_u, cam_fwd = cam_geom(pos, rpy)

        # ── Compute action for each mode ──────────────────────────────────────
        if self._mode == "takeoff":
            # Climb to cruise altitude, yaw toward GPS goal
            yaw_tgt = float(np.arctan2(gps_v[1], gps_v[0]))
            action  = np.array([0., 0., 1., 0.7, _yaw_cmd(yaw_tgt, rpy[2])], np.float32)

        elif self._mode == "cruise":
            # Fly toward GPS center — HORIZONTAL ONLY to prevent excessive tilt
            horiz_dir    = self._gps_center[:2] - pos[:2]  # XY only
            horiz_dist   = float(np.linalg.norm(horiz_dir))

            # Vertical correction — very gentle, max ±0.15 to prevent tilt
            alt_error    = self._min_cruise_alt - alt_to_ground
            vert_blend   = float(np.clip(alt_error * 0.5, -0.5, 0.5))

            if horiz_dist > 1.0:
                horiz_norm = np.array([horiz_dir[0]/horiz_dist, horiz_dir[1]/horiz_dist, 0.], np.float32)
            else:
                horiz_norm = np.array([0., 0., 1.], np.float32)

            combined = np.array([horiz_norm[0], horiz_norm[1], vert_blend], np.float32)
            d_norm   = _norm(combined)

            # Obstacle avoidance
            safe_d = find_safe_dir(
                depth, cam_pos, cam_tgt, cam_r, cam_u, cam_fwd,
                preferred=d_norm,
            )
            # Smoothly interpolate direction — use larger slerp step after takeoff
            safe_d = slerp(self._last_dir, safe_d, 0.05)
            yaw_tgt = float(np.arctan2(safe_d[1], safe_d[0]))
            # Graduated speed ramp — slow start prevents tilt-truncation
            # speed is normalized 0-1 where 1 = SPEED_LIMIT (3.0 m/s)
            # Use 0.3 (~0.9 m/s) for first ~3s after takeoff, ramp up after
            cruise_spd = min(0.8, 0.1 + self._step * 0.004)  # ramp from 0.1 → 0.8 over ~170 steps
            action  = np.array([*safe_d, cruise_spd, _yaw_cmd(yaw_tgt, rpy[2])], np.float32)

        elif self._mode == "nav":
            # Navigate toward ONNX-detected platform
            tgt = self._platform_pos.copy()
            
            # Stage B: Mild Lead Pursuit
            # Predict future position based on conservative lookahead (0.4s max)
            LOOKAHEAD_TIME = 0.4
            tgt[:2] += self._platform_velocity[:2] * LOOKAHEAD_TIME
            
            # Glide slope for MOUNTAIN/FOREST terrains:
            # Maintain high terrain clearance while far away, descend gradually.
            base_target_z = self._goal_z if self._goal_z is not None else tgt[2]
            horiz_dist_to_goal = float(np.linalg.norm(tgt[:2] - pos[:2]))
            
            if getattr(self, '_is_mountainous', False):
                if horiz_dist_to_goal > 20.0:
                    # Stay very high over mountains (which can be 15m tall)
                    target_z = max(float(pos[2]), base_target_z + 10.0)
                elif horiz_dist_to_goal > 8.0:
                    target_z = max(float(pos[2]), base_target_z + 4.0)
                else:
                    target_z = base_target_z + 0.8
            else:
                target_z = base_target_z + 0.8
                
            tgt[2] = target_z
            direction = tgt - pos
            dist_p    = float(np.linalg.norm(direction))

            # Entry speed ramp: prevent tilt spike when entering nav from takeoff.
            # Ramp from 0.25 → 0.833 (NAV_MAX_SPEED) over 35 steps (~0.7s).
            # Extended from 20→35 to cover late-ramp crash at step 28 in WAREHOUSE.
            NAV_SPD_NORM = NAV_MAX_SPEED / SPEED_LIMIT  # 0.833
            entry_ramp   = min(1.0, self._nav_steps / 35.0)
            max_spd      = 0.25 + entry_ramp * (NAV_SPD_NORM - 0.25)  # 0.25 → 0.833

            # Speed: proportional to distance, capped by entry ramp
            if dist_p > 5.0:
                spd = min(max_spd, NAV_MAX_SPEED / SPEED_LIMIT)
            else:
                spd = min(max_spd, max(0.3, dist_p * (NAV_MAX_SPEED / SPEED_LIMIT) / 5.0))

            d_norm = _norm(direction)

            # Obstacle avoidance only when not very close to platform
            # The champion completely disables obstacle avoidance at 4.0m to prevent
            # the platform from triggering collisions. We do the same here but at 1.5m
            if dist_p > 1.5:
                d_norm = find_safe_dir(
                    depth, cam_pos, cam_tgt, cam_r, cam_u, cam_fwd,
                    preferred=d_norm,
                    dist_to_goal=dist_p,
                )

            # Smooth direction — 0.12 (slower than cruise's 0.16) for commitment
            d_norm = slerp(self._last_dir, d_norm, SLERP_T * 1.5)
            yaw_tgt = float(np.arctan2(d_norm[1], d_norm[0]))
            action  = np.array([*d_norm, spd, _yaw_cmd(yaw_tgt, rpy[2])], np.float32)

        elif self._mode == "align":
            # ── ALIGNMENT PHASE ───────────────────────────────────────────────
            anchor = self._landing_anchor if self._landing_anchor is not None else self._platform_pos
            tgt    = anchor.copy()
            
            # Re-introduce lead pursuit for moving platforms during alignment
            if hasattr(self, '_platform_velocity'):
                tgt[:2] += self._platform_velocity[:2] * 0.4
            
            horiz_d = float(np.linalg.norm(pos[:2] - tgt[:2]))
            
            # Maintain altitude or slight glide, NO aggressive descent
            tgt[2] = pos[2]
            
            direction = tgt - pos
            d_norm = _norm(direction)
            
            # Obstacle avoidance: keep side protection active
            d_norm = find_safe_dir(
                depth, cam_pos, cam_tgt, cam_r, cam_u, cam_fwd,
                preferred=d_norm,
                dist_to_goal=horiz_d,
            )
            
            # Damp horizontal velocity for synchronization
            spd = min(0.6, max(0.15, horiz_d / 2.0))
            
            yaw_tgt = float(np.arctan2(d_norm[1], d_norm[0]))
            action  = np.array([*d_norm, spd, _yaw_cmd(yaw_tgt, rpy[2])], np.float32)
            
            # Transition to COMMIT when horizontally synchronized
            # Use tighter threshold to ensure precise centering
            if horiz_d < 0.25:
                self._mode = "commit"

        elif self._mode == "commit":
            # ── COMMIT PHASE ──────────────────────────────────────────────────
            anchor = self._landing_anchor
            tgt    = anchor.copy()
            
            # Small lead pursuit for moving platforms to avoid trailing off during drop
            if hasattr(self, '_platform_velocity'):
                tgt[:2] += self._platform_velocity[:2] * 0.2
            
            horiz_d = float(np.linalg.norm(pos[:2] - tgt[:2]))
            
            direction = tgt - pos
            # Cap lateral correction authority HARD to avoid late oscillation
            direction[0] = float(np.clip(direction[0], -0.15, 0.15))
            direction[1] = float(np.clip(direction[1], -0.15, 0.15))
            direction[2] = min(float(direction[2]), -0.6) # Force descent, but preserve vector geometry
            
            d_norm = _norm(direction)
            
            # Minimum descent velocity, no hovering!
            spd = 0.35
            
            yaw_tgt = float(np.arctan2(d_norm[1], d_norm[0]))
            action  = np.array([*d_norm, spd, _yaw_cmd(yaw_tgt, rpy[2])], np.float32)
            
            altitude_above_pad = float(pos[2] - anchor[2])
            if altitude_above_pad < 0.25:
                self._mode = "touchdown"

        elif self._mode == "touchdown":
            # ── TOUCHDOWN PHASE ───────────────────────────────────────────────
            # Pure downward thrust, NO smoothing, but preserve tiny lateral sync
            anchor = self._landing_anchor
            small_xy = np.clip(anchor[:2] - pos[:2], -0.08, 0.08)
            d_norm = _norm(np.array([small_xy[0], small_xy[1], -1.0], np.float32))
            
            # This directly controls the drone to move -Z at 0.4 m/s
            action = np.array([*d_norm, 0.4, 0.], np.float32)

        else:
            action = np.array([0., 0., 0.3, 0.2, 0.], np.float32)

        # ── Store last direction ───────────────────────────────────────────────
        dir_norm = action[:3]
        if np.linalg.norm(dir_norm) > 1e-4:
            self._last_dir = _norm(dir_norm)

        # ── Champion-exact first-order velocity integrator ────────────────────
        # Active during cruise + nav (search + navigation in champion parlance).
        # Passes through unchanged during takeoff + land (full maneuverability),
        # but ALWAYS updates prev_action so the next integration-active mode
        # starts from a warm state — zero transition discontinuity.
        # Apply velocity integrator only in cruise mode to prevent double-filtering lag in nav mode
        # ── Integration logic ──────────────────────────────────────────────────
        # Disable integrator only in terminal landing to prevent sudden nav tilts
        action = np.clip(action, -1.0, 1.0)
        use_integrator = self._mode in ("cruise", "nav", "align")
        return self._getFirstOrderAction(action, is_first_order=use_integrator)
